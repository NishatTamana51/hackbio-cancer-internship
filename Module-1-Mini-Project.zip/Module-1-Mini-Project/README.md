The file Bioinformatic Mini_ Project file contain the information you need to complete Our Module one project and participate in our Internship challenge!
